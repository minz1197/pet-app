import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpet',
  templateUrl: './editpet.component.html',
  styleUrls: ['./editpet.component.css']
})
export class EditpetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
