import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newpet',
  templateUrl: './newpet.component.html',
  styleUrls: ['./newpet.component.css']
})
export class NewpetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
