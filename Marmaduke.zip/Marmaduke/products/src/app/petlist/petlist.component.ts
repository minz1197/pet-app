import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-petlist',
  templateUrl: './petlist.component.html',
  styleUrls: ['./petlist.component.css']
})
export class PetlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
