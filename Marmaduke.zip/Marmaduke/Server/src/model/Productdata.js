const mongoose =require('mongoose');
mongoose.connect('mongodb://localhost:27017/PetDb');


const Schema = mongoose.Schema;
var NewProductSchema = new Schema({
  
    productId : Number,
    productBreed : String,
    productPrice : Number,
    productAge: Number,
    imageUrl : String
})


module.exports = mongoose.model('ProductData',NewProductSchema,'products');